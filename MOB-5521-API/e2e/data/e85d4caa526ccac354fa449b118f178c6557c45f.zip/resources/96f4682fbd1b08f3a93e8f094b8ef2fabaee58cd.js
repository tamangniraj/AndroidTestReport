// window.viveka = window.singleSpaAngularjs.default({
//   angular: window.angular,
//   domElementGetter: function () {
//     return document.getElementById('viveka')
//   },
//   mainAngularModule: 'viveka-app',
//   uiRouter: true,
//   preserveGlobal: true,
//   template: '<viveka-app />',
// })
//
// window.singleSpa.registerApplication('viveka-app', viveka, function activityFunction(location) {
//   return true;
// })

// window.singleSpa.registerApplication({
//   name: "@viveka/viveka-ui",
//   app: function() { return System.import('@viveka/viveka-ui'); },
//   activeWhen: ['/#/admin']
// })

var timeout = setInterval(function (){
  if(window && window.angular){
    loadSystem();
  }
}, 5);
var loadSystem = function (){
  clearInterval(timeout);
  System.import('single-spa').then(function (singleSpa) {
    System.import('single-spa-angularjs').then(function (singleSpaAngularjs) {
      // window.singleSpa = singleSpa;
      // window.singleSpaAngularjs = singleSpaAngularjs;

      // Pre-load microfrontends; failures are logged but never block startup
      var vivekaDeps = System.import('@viveka/viveka-ui').catch(function (err) {
        console.error('[single-spa] @viveka/viveka-ui failed to load:', err);
      });
      var employerDeps = System.import('@viveka/employer-portal-ui').catch(function (err) {
        console.error('[single-spa] @viveka/employer-portal-ui failed to load:', err);
      });
      System.import('@viveka/remittance-v2-ui').catch(function () {});
      System.import('@viveka/pension-management-ui').then(function () {
        console.log('pension-management-ui loaded successfully');
      }, function () {
        console.warn('pension-management-ui not available - skipping');
      });

      Promise.all([vivekaDeps, employerDeps]).then(function () {
        setTimeout(function () {
          singleSpa.registerApplication({
            name: 'viveka',
            app: function () {
              return Promise.resolve(singleSpaAngularjs.default.default({
                angular: window.angular,
                mainAngularModule: 'viveka',
                uiRouter: true,
                preserveGlobal: false,
                template: '<viveka-app />',
              }));
            },
            activeWhen: ['/'],
          });

          singleSpa.registerApplication({
            name: '@viveka/viveka-ui',
            app: function () {
              return System.import('@viveka/viveka-ui');
            },
            activeWhen: ['/#/', '/#/customer-service', '/#/members/list', '/#/members/details', '/#/reports/message-reporting', '/#/admin/userSummary', '/#/admin/dashboard', '/#/admin/registrationReport', '/#/paymentsV2', '/#/admin/survey/create', '/#/admin/survey/dashboard', '/#/admin/survey/report', '/#/admin/registrationReport'],
          });

          singleSpa.registerApplication({
            name: '@viveka/employer-portal-ui',
            app: function () {
              return System.import('@viveka/employer-portal-ui');
            },
            activeWhen: ['/#/remittances/remittance_home/:id', '/#/remittances/remittance_home/:id/employerV2/:employerid'],
          });

          singleSpa.registerApplication({
            name: '@viveka/remittance-v2-ui',
            app: function () {
              return System.import('@viveka/remittance-v2-ui');
            },
            activeWhen: function(location) {
              return location.hash.startsWith('#/remittanceV2') ||
                     location.hash.startsWith('#/members/list') ||
                     location.hash.startsWith('#/members/details');
            },
          });

          singleSpa.registerApplication({
            name: '@viveka/pension-management-ui',
            app: function () {
              return System.import('@viveka/pension-management-ui');
            },
            activeWhen: ['/#/pension-management'],
          });

          singleSpa.registerApplication({
            name: '@viveka/mobile-admin-portal',
            app: function () {
              return System.import('@viveka/mobile-admin-portal').catch(function (err) {
                console.error('[single-spa] @viveka/mobile-admin-portal failed to load:', err);
                return Promise.reject(err);
              });
            },
            activeWhen: function(location) {
              return location.hash === '#/mobile' || location.hash.startsWith('#/mobile/');
            },
          });

          singleSpa.start();
        }, 200);
      });
    });
  });
};

// window.singleSpa.registerApplication('viveka', viveka, function activityFunction(location) {
//   return true;
// })

// window.singleSpa.registerApplication({
//   name: "@viveka/viveka-ui",
//   app: function () { return System.import("@viveka/viveka-ui"); },
//   activeWen: ["/new "]
// })
// var helloWorldApp = {
//   bootstrap: function() {
//     return Promise.resolve()
//   },
//   mount: function() {
//     return Promise.resolve().then(function() {
//       alert('hello world')
//     })
//   },
//   unmount: function() {
//     return Promise.resolve()
//   },
// }
// window.singleSpa.registerApplication('hello-world', helloWorldApp, function activityFunction(location) {
//   return location.hash.startsWith('#/hello');
// })
